import { AlquilerPipe } from './alquiler.pipe';

describe('AlquilerPipe', () => {
  it('create an instance', () => {
    const pipe = new AlquilerPipe();
    expect(pipe).toBeTruthy();
  });
});
